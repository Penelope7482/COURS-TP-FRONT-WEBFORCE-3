Pour initialiser: le cdn fourni par le github n'est pas bon. Prendre celui-ci (récupéré sur le site cdnjs)

<script src='https://cdnjs.cloudflare.com/ajax/libs/dragula/3.7.2/dragula.min.js'></script>

Lien vers le github et la doc:

https://github.com/bevacqua/dragula

